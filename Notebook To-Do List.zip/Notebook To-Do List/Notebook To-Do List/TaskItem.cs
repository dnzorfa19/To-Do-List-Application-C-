﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notebook_To_Do_List
{
    internal class TaskItem
    {
        public int Id { get; set; } // Her görev için ID
        public string Title { get; set; }
        public bool IsCompleted { get; set; }

        public override string ToString()
        {
            string status = IsCompleted ? "[X]" : "[ ]";
            return $"{Id}. {status} {Title}";
        }
    }
}
