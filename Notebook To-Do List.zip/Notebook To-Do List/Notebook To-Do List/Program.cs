﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notebook_To_Do_List
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DataService dataService = new DataService();
            List<TaskItem> tasks = dataService.LoadTasks();
            int nextId = tasks.Count > 0 ? tasks.Max(t => t.Id) + 1 : 1;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("📝 To-Do List Uygulaması");
                Console.WriteLine("------------------------");
                Console.WriteLine("1 - Görev Ekle");
                Console.WriteLine("2 - Görevleri Listele");
                Console.WriteLine("3 - Görev Tamamla");
                Console.WriteLine("4 - Görev Sil");
                Console.WriteLine("0 - Çıkış");
                Console.Write("Seçiminiz: ");
                string choice = Console.ReadLine() ?? "";

                switch (choice)
                {
                    case "1":
                        Console.Write("Görev Başlığı: ");
                        string title = Console.ReadLine() ?? "";
                        if (string.IsNullOrWhiteSpace(title))
                        {
                            Console.WriteLine("Görev boş olamaz!");
                        }
                        else
                        {
                            tasks.Add(new TaskItem { Id = nextId++, Title = title, IsCompleted = false });
                            dataService.SaveTasks(tasks);
                            Console.WriteLine("Görev eklendi!");
                        }
                        break;

                    case "2":
                        Console.WriteLine("\n📋 Görevler:");
                        foreach (var task in tasks)
                        {
                            Console.WriteLine(task);
                        }
                        break;

                    case "3":
                        Console.Write("Tamamlanacak görev ID'si: ");
                        if (int.TryParse(Console.ReadLine(), out int completeId))
                        {
                            var task = tasks.FirstOrDefault(t => t.Id == completeId);
                            if (task != null)
                            {
                                task.IsCompleted = true;
                                dataService.SaveTasks(tasks);
                                Console.WriteLine("Görev tamamlandı!");
                            }
                            else
                            {
                                Console.WriteLine("Görev bulunamadı.");
                            }
                        }
                        break;

                    case "4":
                        Console.Write("Silinecek görev ID'si: ");
                        if (int.TryParse(Console.ReadLine(), out int deleteId))
                        {
                            var task = tasks.FirstOrDefault(t => t.Id == deleteId);
                            if (task != null)
                            {
                                tasks.Remove(task);
                                dataService.SaveTasks(tasks);
                                Console.WriteLine("Görev silindi!");
                            }
                            else
                            {
                                Console.WriteLine("Görev bulunamadı.");
                            }
                        }
                        break;

                    case "0":
                        dataService.SaveTasks(tasks);
                        return;

                    default:
                        Console.WriteLine("Geçersiz seçim!");
                        break;
                }

                Console.WriteLine("\nDevam etmek için bir tuşa bas...");
                Console.ReadKey();

            }
        }
    }
}
